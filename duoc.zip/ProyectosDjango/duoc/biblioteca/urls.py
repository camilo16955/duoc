from django.urls import path
from .views import index, categorias, contacto, hiphop, pop, rock
urlpatterns = [
    path('index', index, name="index"),
    path('index/categorias', categorias, name="categorias"),
    path('index/contacto', contacto, name="contacto"),
    path('index/hiphop', hiphop, name="hiphop"),
    path('index/pop', pop, name="pop"),
    path('index/rock', rock, name="rock"),
   
]